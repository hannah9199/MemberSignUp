package pet.member;

import pet.common.SuperClass;

public class MemberLogOutController extends SuperClass {

}
