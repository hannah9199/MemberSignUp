package pet.member;

import pet.common.SuperClass;

public class MemberListController extends SuperClass {

}
