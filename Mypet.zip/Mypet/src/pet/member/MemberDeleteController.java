package pet.member;

import pet.common.SuperClass;

public class MemberDeleteController extends SuperClass {

}
