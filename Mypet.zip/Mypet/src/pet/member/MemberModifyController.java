package pet.member;

import pet.common.SuperClass;

public class MemberModifyController extends SuperClass {

}
