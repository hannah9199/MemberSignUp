package pet.member;

import pet.common.SuperClass;

public class MemberLoginController extends SuperClass {

}
