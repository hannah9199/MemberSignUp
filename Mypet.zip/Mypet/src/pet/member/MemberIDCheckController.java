package pet.member;

import pet.common.SuperClass;

public class MemberIDCheckController extends SuperClass {

}
