package pet.dao;

public class MemberDao extends SuperDao {

}
